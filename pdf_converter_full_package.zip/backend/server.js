const express = require('express');
const multer = require('multer');
const mongoose = require('mongoose');
const cors = require('cors');
const File = require('./models/File');

const app = express();
const PORT = 5000;
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname),
});
const upload = multer({ storage });

mongoose.connect('mongodb://localhost:27017/pdf_converter', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.post('/upload', upload.single('file'), async (req, res) => {
  const newFile = new File({
    filename: req.file.filename,
    path: req.file.path,
    uploadedAt: new Date(),
  });
  await newFile.save();
  res.json({ success: true, path: `/uploads/${req.file.filename}` });
});

app.get('/history', async (req, res) => {
  const files = await File.find().sort({ uploadedAt: -1 }).limit(10);
  res.json(files);
});

app.listen(PORT, () => console.log(`Server running at http://localhost:${PORT}`));